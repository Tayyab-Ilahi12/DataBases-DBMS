<?php
    session_start();
    
    if(isset($_SESSION["user"]))
    {
        if($_SESSION["type"] != "academic")
            header("Location:st_home.php");
    }
    else
        header("Location:login.php");
?>

<html>
<head>
	<title>Student Registeration</title>
</head>
<body>
    <div align="right">
        <span>
            <?php
                echo "Welcome ".$_SESSION["user"];
            ?>
            <a href="logout.php">Logout</a>
        </span>
    </div>
	<form action="register_try.php" method="post">
		<table align="center">
			<th colspan="2">Student's Registeration</th>
			<tr>
				<td>
					Roll No
				</td>
				<td>
					<input type="text" name="txtRollNo" id="txtRollNo" onblur="genEmail()" required>
				</td>
			</tr>
			<tr>
				<td>
					Name
				</td>
				<td>
					<input type="text" name="txtName" id="txtName" onblur="checkName()" required>
				</td>
                <td>
                    <span id="nMsg">
                    </span>
                </td>
			</tr>
			<tr>
				<td>
					Father's Name
				</td>
				<td>
					<input type="text" name="txtFName" required>
				</td>
			</tr>
			<tr>
				<td>
					Gender
				</td>
				<td>
					<select name="sGender" required>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select>
				</td>
			</tr>
            <tr>
				<td>
					Email
				</td>
				<td>
					<input type="text" name="txtEmail" id="txtEmail" required>
				</td>
			</tr>
			<tr>
				<td>
					Contact No.
				</td>
				<td>
					<input type="text" name="txtContact" required>
				</td>
			</tr>
			<tr>
				<td>
					Address
				</td>
				<td>
					<textarea name="txtAddress" required></textarea>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="right">
					<input type="submit" value="Register">
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<?php
						if (isset($_GET["Message"])) {
							echo $_GET["Message"];
						}
					?>
				</td>
			</tr>
		</table>
	</form>
</body>
<script type="text/javascript">
    function checkName()
    {
        var nameBox = document.getElementById("txtName");
        var name = nameBox.value;
        var nMsg = document.getElementById("nMsg");
        //alert(name);
        if(Number(name))
        {
            nMsg.innerHTML = "Invalid name...";
            nameBox.value = "";
            nameBox.focus();
        }
        else
            nMsg.innerHTML = "";
    }
    function genEmail()
    {
        var roll = document.getElementById("txtRollNo").value;
        var emailBox = document.getElementById("txtEmail");
        
        //"p19-6104"
        //"p196104@nu.edu.pk"
        
        
        var splitRoll = roll.split("-");
        var email = splitRoll[0]+splitRoll[1]+"@nu.edu.pk";
        
        emailBox.value = email;
    }
</script>
</html>













