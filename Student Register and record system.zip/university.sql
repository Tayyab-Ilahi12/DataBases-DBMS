-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2019 at 03:22 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `academic_users`
-- (See below for the actual view)
--
CREATE TABLE `academic_users` (
`uid` int(11)
,`user_name` varchar(10)
,`password` varchar(30)
,`type` varchar(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `roll_no` varchar(10) NOT NULL,
  `st_name` varchar(30) NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(16) NOT NULL,
  `address` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`roll_no`, `st_name`, `f_name`, `gender`, `contact`, `address`) VALUES
('', '', '', '', '', ''),
('P19-1000', 'tre', 'uyi', 'Male', '03339177702', 'Lahore'),
('P19-1001', 'tre', 'uyi', 'Male', '03339177702', 'Lahore'),
('P19-1003', 'Ali Azmat', 'Azmat Khan', 'Male', '03339177703', 'Peshawar'),
('P19-1004', 'Jamal Khan', 'Samandar Khan', 'Male', '03339177707', 'peshawar'),
('P19-1005', 'Kamran Jamal', 'Jamal Ali', 'Male', '03339177777', 'Islamabad'),
('P19-1009', 'tre', 'uyi', 'Male', '03339177702', 'Lahore'),
('P19-6015', 'Ali Abbas Khan', 'Khan sb', 'Male', '03339174258', 'asdjflasdjfl'),
('p20-1234', 'abc', 'def', 'Male', '123', 'Kohat'),
('P20-6005', 'abc', 'def', 'Male', '75675', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `user_name` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `user_name`, `password`, `type`) VALUES
(1, 'zahoor', 'teatime', 'academic'),
(2, 'fahad', 'teatime', 'student'),
(4, 'waqar', 'teatime', 'student'),
(5, 'amjad', 'teatime', 'academic');

-- --------------------------------------------------------

--
-- Structure for view `academic_users`
--
DROP TABLE IF EXISTS `academic_users`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `academic_users`  AS  select `users`.`uid` AS `uid`,`users`.`user_name` AS `user_name`,`users`.`password` AS `password`,`users`.`type` AS `type` from `users` where (`users`.`type` = 'academic') WITH CASCADED CHECK OPTION ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
